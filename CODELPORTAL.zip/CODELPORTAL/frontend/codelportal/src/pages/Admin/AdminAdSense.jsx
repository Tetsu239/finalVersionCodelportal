import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import {
  Plus,
  Edit2,
  Trash2,
  Eye,
  EyeOff,
  AlertCircle,
  CheckCircle,
  Loader,
} from "lucide-react";
import axiosInstance from "../../utils/axiosInstance";
import { API_PATHS } from "../../utils/apiPaths";
import toast from "react-hot-toast";

const AdminAdSense = () => {
  const [adZones, setAdZones] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingZone, setEditingZone] = useState(null);
  const [formData, setFormData] = useState({
    zoneId: "",
    name: "",
    description: "",
    placement: "inline",
    position: "bottom",
    width: 300,
    height: 250,
    adsenseCode: "",
    adsenseSlotId: "",
    pages: ["all"],
  });

  useEffect(() => {
    fetchAdZones();
  }, []);

  const fetchAdZones = async () => {
    try {
      const response = await axiosInstance.get(API_PATHS.ADS.GET_ALL_ZONES);
      setAdZones(response.data);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching ad zones:", error);
      toast.error("Failed to fetch ad zones");
      setLoading(false);
    }
  };

  const resetForm = () => {
    setFormData({
      zoneId: "",
      name: "",
      description: "",
      placement: "inline",
      position: "bottom",
      width: 300,
      height: 250,
      adsenseCode: "",
      adsenseSlotId: "",
      pages: ["all"],
    });
    setEditingZone(null);
    setShowForm(false);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handlePageToggle = (page) => {
    setFormData((prev) => ({
      ...prev,
      pages: prev.pages.includes(page)
        ? prev.pages.filter((p) => p !== page)
        : [...prev.pages, page],
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.zoneId || !formData.name) {
      toast.error("Zone ID and Name are required");
      return;
    }

    try {
      if (editingZone) {
        // Update existing zone
        await axiosInstance.put(API_PATHS.ADS.UPDATE_ZONE(editingZone.zoneId), formData);
        toast.success("Ad zone updated successfully");
      } else {
        // Create new zone
        await axiosInstance.post(API_PATHS.ADS.CREATE_ZONE, formData);
        toast.success("Ad zone created successfully");
      }

      fetchAdZones();
      resetForm();
    } catch (error) {
      toast.error(error.response?.data?.message || "Error saving ad zone");
    }
  };

  const handleEdit = (zone) => {
    setEditingZone(zone);
    setFormData({
      zoneId: zone.zoneId,
      name: zone.name,
      description: zone.description,
      placement: zone.placement,
      position: zone.position,
      width: zone.width,
      height: zone.height,
      adsenseCode: zone.adsenseCode || "",
      adsenseSlotId: zone.adsenseSlotId || "",
      pages: zone.pages,
    });
    setShowForm(true);
  };

  const handleToggleStatus = async (zone) => {
    try {
      await axiosInstance.patch(API_PATHS.ADS.TOGGLE_ZONE(zone.zoneId));
      toast.success(`Ad zone ${!zone.isActive ? "activated" : "deactivated"}`);
      fetchAdZones();
    } catch (error) {
      toast.error("Error toggling ad zone status");
    }
  };

  const handleDelete = async (zoneId) => {
    if (window.confirm("Are you sure you want to delete this ad zone?")) {
      try {
        await axiosInstance.delete(API_PATHS.ADS.DELETE_ZONE(zoneId));
        toast.success("Ad zone deleted successfully");
        fetchAdZones();
      } catch (error) {
        toast.error("Error deleting ad zone");
      }
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <Loader className="w-12 h-12 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">AdSense Management</h1>
            <p className="text-gray-600 mt-2">
              Manage advertising zones and Google AdSense codes
            </p>
          </div>
          <button
            onClick={() => setShowForm(true)}
            className="flex items-center space-x-2 bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Plus className="w-5 h-5" />
            <span>Add New Zone</span>
          </button>
        </div>

        {/* Form Modal */}
        {showForm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
            >
              <div className="sticky top-0 bg-white border-b p-6 flex justify-between items-center">
                <h2 className="text-2xl font-bold">
                  {editingZone ? "Edit Ad Zone" : "Create New Ad Zone"}
                </h2>
                <button
                  onClick={resetForm}
                  className="text-gray-500 hover:text-gray-700"
                >
                  ×
                </button>
              </div>

              <form onSubmit={handleSubmit} className="p-6 space-y-6">
                {/* Zone ID and Name */}
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Zone ID (unique) *
                    </label>
                    <input
                      type="text"
                      name="zoneId"
                      value={formData.zoneId}
                      onChange={handleInputChange}
                      disabled={editingZone}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg disabled:bg-gray-100"
                      placeholder="e.g., header-banner"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Zone Name *
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                      placeholder="e.g., Header Banner Ad"
                    />
                  </div>
                </div>

                {/* Description */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Description
                  </label>
                  <textarea
                    name="description"
                    value={formData.description}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                    rows="3"
                    placeholder="Describe this ad zone..."
                  />
                </div>

                {/* Placement and Position */}
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Placement Type
                    </label>
                    <select
                      name="placement"
                      value={formData.placement}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                    >
                      <option value="inline">Inline</option>
                      <option value="sticky">Sticky</option>
                      <option value="floating">Floating</option>
                      <option value="fixed">Fixed</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Position
                    </label>
                    <select
                      name="position"
                      value={formData.position}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                    >
                      <option value="top">Top</option>
                      <option value="bottom">Bottom</option>
                      <option value="left">Left</option>
                      <option value="right">Right</option>
                    </select>
                  </div>
                </div>

                {/* Width and Height */}
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Width (px)
                    </label>
                    <input
                      type="number"
                      name="width"
                      value={formData.width}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Height (px)
                    </label>
                    <input
                      type="number"
                      name="height"
                      value={formData.height}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                    />
                  </div>
                </div>

                {/* AdSense Slot ID */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Google AdSense Slot ID
                  </label>
                  <input
                    type="text"
                    name="adsenseSlotId"
                    value={formData.adsenseSlotId}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                    placeholder="e.g., 1234567890"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Found in your Google AdSense account settings
                  </p>
                </div>

                {/* AdSense Code */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Google AdSense Code
                  </label>
                  <textarea
                    name="adsenseCode"
                    value={formData.adsenseCode}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg font-mono text-xs"
                    rows="6"
                    placeholder="Paste your Google AdSense code here..."
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Paste the complete code snippet from Google AdSense
                  </p>
                </div>

                {/* Pages */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-3">
                    Display on Pages
                  </label>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { value: "all", label: "All Pages" },
                      { value: "services", label: "Services" },
                      { value: "developer-tools", label: "Developer Tools" },
                      { value: "free-tools", label: "Free Tools" },
                      { value: "landing-page", label: "Landing Page" },
                      { value: "job-details", label: "Job Details" },
                    ].map((page) => (
                      <label key={page.value} className="flex items-center space-x-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={formData.pages.includes(page.value)}
                          onChange={() => handlePageToggle(page.value)}
                          className="w-4 h-4 text-blue-600"
                        />
                        <span className="text-sm text-gray-700">{page.label}</span>
                      </label>
                    ))}
                  </div>
                </div>

                {/* Buttons */}
                <div className="flex space-x-4 pt-6 border-t">
                  <button
                    type="submit"
                    className="flex-1 bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    {editingZone ? "Update Zone" : "Create Zone"}
                  </button>
                  <button
                    type="button"
                    onClick={resetForm}
                    className="flex-1 bg-gray-200 text-gray-700 px-6 py-2 rounded-lg hover:bg-gray-300 transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}

        {/* Ad Zones Table */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-lg shadow"
        >
          {adZones.length === 0 ? (
            <div className="p-12 text-center">
              <AlertCircle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">No ad zones created yet</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">
                      Zone Name
                    </th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">
                      Zone ID
                    </th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">
                      Impressions
                    </th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {adZones.map((zone) => (
                    <tr key={zone._id} className="border-b hover:bg-gray-50 transition-colors">
                      <td className="px-6 py-4">
                        <div>
                          <p className="font-medium text-gray-900">{zone.name}</p>
                          <p className="text-sm text-gray-500">{zone.description}</p>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-600">{zone.zoneId}</td>
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-2">
                          {zone.isActive ? (
                            <>
                              <Eye className="w-4 h-4 text-green-600" />
                              <span className="text-sm text-green-600">Active</span>
                            </>
                          ) : (
                            <>
                              <EyeOff className="w-4 h-4 text-gray-400" />
                              <span className="text-sm text-gray-500">Inactive</span>
                            </>
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-600">{zone.impressions}</td>
                      <td className="px-6 py-4">
                        <div className="flex space-x-2">
                          <button
                            onClick={() => handleToggleStatus(zone)}
                            className="p-2 hover:bg-gray-200 rounded-lg transition-colors"
                            title={zone.isActive ? "Deactivate" : "Activate"}
                          >
                            {zone.isActive ? (
                              <EyeOff className="w-4 h-4 text-gray-600" />
                            ) : (
                              <Eye className="w-4 h-4 text-gray-600" />
                            )}
                          </button>
                          <button
                            onClick={() => handleEdit(zone)}
                            className="p-2 hover:bg-gray-200 rounded-lg transition-colors"
                            title="Edit"
                          >
                            <Edit2 className="w-4 h-4 text-blue-600" />
                          </button>
                          <button
                            onClick={() => handleDelete(zone.zoneId)}
                            className="p-2 hover:bg-gray-200 rounded-lg transition-colors"
                            title="Delete"
                          >
                            <Trash2 className="w-4 h-4 text-red-600" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </motion.div>

        {/* Stats Summary */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8"
        >
          <div className="bg-white rounded-lg shadow p-6">
            <p className="text-gray-600 text-sm">Total Ad Zones</p>
            <p className="text-3xl font-bold text-gray-900">{adZones.length}</p>
          </div>
          <div className="bg-white rounded-lg shadow p-6">
            <p className="text-gray-600 text-sm">Active Zones</p>
            <p className="text-3xl font-bold text-blue-600">
              {adZones.filter((z) => z.isActive).length}
            </p>
          </div>
          <div className="bg-white rounded-lg shadow p-6">
            <p className="text-gray-600 text-sm">Total Impressions</p>
            <p className="text-3xl font-bold text-green-600">
              {adZones.reduce((sum, z) => sum + z.impressions, 0)}
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default AdminAdSense;
