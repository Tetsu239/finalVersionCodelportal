

const Analytics = () => {
  return (
    <div></div>
  )
}

export default Analytics