import React from "react";
import { motion } from "framer-motion";
import {
  FileText,
  Calculator,
  Palette,
  Clock,
  MapPin,
  BarChart3,
  DollarSign,
  Thermometer,
} from "lucide-react";
import Navbar from "../../components/layout/Navbar";
import Footer from "../../components/layout/Footer";
import AdZone from "../../components/AdZone";

const FreeTools = () => {
  const freeTools = [
    {
      icon: FileText,
      title: "Resume Builder",
      description: "Create a professional resume in minutes with our template builder",
      category: "Career",
    },
    {
      icon: Calculator,
      title: "Salary Calculator",
      description: "Calculate your expected salary based on role and experience",
      category: "Finance",
    },
    {
      icon: Palette,
      title: "Design Templates",
      description: "Free design templates for job applications and portfolios",
      category: "Design",
    },
    {
      icon: Clock,
      title: "Time Zone Converter",
      description: "Convert time zones for remote job interviews",
      category: "Utility",
    },
    {
      icon: MapPin,
      title: "Remote Job Finder",
      description: "Find remote job opportunities in your preferred location",
      category: "Jobs",
    },
    {
      icon: BarChart3,
      title: "Market Analytics",
      description: "Analyze job market trends and in-demand skills",
      category: "Analytics",
    },
    {
      icon: DollarSign,
      title: "Expense Tracker",
      description: "Track job search expenses and budgeting",
      category: "Finance",
    },
    {
      icon: Thermometer,
      title: "Interview Prep",
      description: "Practice common interview questions and answers",
      category: "Learning",
    },
  ];

  const categories = ["All", "Career", "Finance", "Design", "Utility", "Jobs", "Analytics", "Learning"];

  return (
    <>
      <Navbar />
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-r from-green-600 to-green-800 text-white py-16 px-4"
        >
          <div className="max-w-6xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Free Tools</h1>
            <p className="text-xl text-green-100">
              Powerful, free tools to help you succeed in your job search
            </p>
          </div>
        </motion.div>

        {/* Top Ad Zone */}
        <div className="max-w-6xl mx-auto px-4 py-8">
          <AdZone zoneId="free-tools-top" placement="inline" />
        </div>

        {/* Category Filter */}
        <div className="max-w-6xl mx-auto px-4 py-8">
          <div className="flex flex-wrap gap-4 justify-center">
            {categories.map((category) => (
              <motion.button
                key={category}
                whileHover={{ scale: 1.05 }}
                className={`px-6 py-2 rounded-full font-semibold transition-all ${
                  category === "All"
                    ? "bg-green-600 text-white"
                    : "bg-white text-gray-700 hover:bg-gray-100"
                }`}
              >
                {category}
              </motion.button>
            ))}
          </div>
        </div>

        {/* Tools Grid */}
        <div className="max-w-6xl mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {freeTools.map((tool, index) => {
              const Icon = tool.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-all cursor-pointer group"
                >
                  <div className="bg-gradient-to-r from-green-500 to-green-600 p-6">
                    <Icon className="w-12 h-12 text-white mb-2" />
                    <span className="text-xs font-semibold text-green-100 bg-green-800 bg-opacity-50 px-2 py-1 rounded-full">
                      {tool.category}
                    </span>
                  </div>
                  <div className="p-6">
                    <h3 className="text-lg font-bold text-gray-900 mb-2">
                      {tool.title}
                    </h3>
                    <p className="text-gray-600 text-sm mb-4">{tool.description}</p>
                    <button className="w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 transition-colors text-sm font-semibold group-hover:translate-y-[-2px] transition-transform">
                      Launch Tool
                    </button>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Middle Ad Zone */}
        <div className="max-w-6xl mx-auto px-4 py-8">
          <AdZone zoneId="free-tools-middle" placement="sticky" position="bottom" />
        </div>

        {/* Premium Upgrade */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          className="bg-white py-16 px-4 my-16"
        >
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Want even more features?
            </h2>
            <p className="text-lg text-gray-600 mb-8">
              Upgrade to premium for advanced tools, priority support, and exclusive features
            </p>
            <button className="bg-gradient-to-r from-green-600 to-green-700 text-white px-8 py-3 rounded-lg font-semibold hover:from-green-700 hover:to-green-800 transition-all">
              Go Premium
            </button>
          </div>
        </motion.div>

        {/* Bottom Ad Zone */}
        <div className="max-w-6xl mx-auto px-4 py-8">
          <AdZone zoneId="free-tools-bottom" placement="floating" position="bottom" />
        </div>
      </div>
      <Footer />
    </>
  );
};

export default FreeTools;
