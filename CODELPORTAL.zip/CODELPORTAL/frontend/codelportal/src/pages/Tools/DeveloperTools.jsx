import React, { useState } from "react";
import { motion } from "framer-motion";
import {
  Code,
  Palette,
  Cpu,
  Database,
  Shield,
  Zap,
  Copy,
  Check,
} from "lucide-react";
import Navbar from "../../components/layout/Navbar";
import Footer from "../../components/layout/Footer";
import AdZone from "../../components/AdZone";
import toast from "react-hot-toast";

const DeveloperTools = () => {
  const [copiedId, setCopiedId] = useState(null);

  const tools = [
    {
      icon: Code,
      title: "JSON Formatter",
      description: "Format and validate JSON code with syntax highlighting",
      tool: "json-formatter",
    },
    {
      icon: Palette,
      title: "Color Picker",
      description: "Pick and convert colors between different formats",
      tool: "color-picker",
    },
    {
      icon: Cpu,
      title: "Base64 Encoder",
      description: "Encode and decode text using Base64",
      tool: "base64-encoder",
    },
    {
      icon: Database,
      title: "CSV to JSON",
      description: "Convert CSV files to JSON format instantly",
      tool: "csv-to-json",
    },
    {
      icon: Shield,
      title: "Password Generator",
      description: "Generate strong and secure passwords",
      tool: "password-generator",
    },
    {
      icon: Zap,
      title: "Regex Tester",
      description: "Test and validate regular expressions",
      tool: "regex-tester",
    },
  ];

  const copyToClipboard = (text, id) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    toast.success("Copied to clipboard!");
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <>
      <Navbar />
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-r from-purple-600 to-purple-800 text-white py-16 px-4"
        >
          <div className="max-w-6xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Developer Tools</h1>
            <p className="text-xl text-purple-100">
              Essential tools for developers and engineers
            </p>
          </div>
        </motion.div>

        {/* Top Ad Zone */}
        <div className="max-w-6xl mx-auto px-4 py-8">
          <AdZone zoneId="dev-tools-top" placement="inline" />
        </div>

        {/* Tools Grid */}
        <div className="max-w-6xl mx-auto px-4 py-16">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {tools.map((tool, index) => {
              const Icon = tool.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition-all cursor-pointer group"
                >
                  <div className="flex items-center justify-between mb-4">
                    <Icon className="w-10 h-10 text-purple-600 group-hover:scale-110 transition-transform" />
                    <button
                      onClick={() => copyToClipboard(tool.tool, tool.tool)}
                      className="text-gray-400 hover:text-gray-600"
                    >
                      {copiedId === tool.tool ? (
                        <Check className="w-5 h-5 text-green-600" />
                      ) : (
                        <Copy className="w-5 h-5" />
                      )}
                    </button>
                  </div>
                  <h3 className="text-lg font-bold text-gray-900 mb-2">
                    {tool.title}
                  </h3>
                  <p className="text-gray-600 text-sm mb-4">{tool.description}</p>
                  <button className="w-full bg-purple-600 text-white py-2 rounded-lg hover:bg-purple-700 transition-colors text-sm font-semibold">
                    Launch Tool
                  </button>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Middle Ad Zone */}
        <div className="max-w-6xl mx-auto px-4 py-8">
          <AdZone zoneId="dev-tools-middle" placement="sticky" position="bottom" />
        </div>

        {/* Documentation Section */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          className="bg-white py-16 px-4 my-16"
        >
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">
              API Documentation
            </h2>
            <div className="bg-gray-50 rounded-lg p-8">
              <p className="text-gray-700 mb-4">
                All our developer tools are available via REST API. Get started with our
                comprehensive documentation.
              </p>
              <button className="bg-purple-600 text-white px-6 py-2 rounded-lg hover:bg-purple-700 transition-colors">
                View API Docs
              </button>
            </div>
          </div>
        </motion.div>

        {/* Bottom Ad Zone */}
        <div className="max-w-6xl mx-auto px-4 py-8">
          <AdZone zoneId="dev-tools-bottom" placement="floating" position="bottom" />
        </div>
      </div>
      <Footer />
    </>
  );
};

export default DeveloperTools;
