import React from "react";
import { motion } from "framer-motion";
import {
  Code2,
  Briefcase,
  Users,
  TrendingUp,
  Shield,
  Zap,
} from "lucide-react";
import Navbar from "../../components/layout/Navbar";
import Footer from "../../components/layout/Footer";
import AdZone from "../../components/AdZone";

const Services = () => {
  const services = [
    {
      icon: Code2,
      title: "Job Posting",
      description: "Post your job openings and reach thousands of qualified candidates",
      features: ["Unlimited postings", "Advanced filtering", "Analytics dashboard"],
    },
    {
      icon: Users,
      title: "Candidate Management",
      description: "Manage applications and track candidate progress efficiently",
      features: ["Application tracking", "Email notifications", "Rating system"],
    },
    {
      icon: Briefcase,
      title: "Profile Building",
      description: "Create professional profiles and showcase your expertise",
      features: ["CV upload", "Portfolio showcase", "Skill endorsements"],
    },
    {
      icon: TrendingUp,
      title: "Analytics & Insights",
      description: "Get detailed insights on your job postings and applications",
      features: ["Performance metrics", "Trending skills", "Market insights"],
    },
    {
      icon: Shield,
      title: "Security & Privacy",
      description: "Your data is protected with enterprise-grade security",
      features: ["Data encryption", "Privacy controls", "GDPR compliant"],
    },
    {
      icon: Zap,
      title: "Premium Features",
      description: "Unlock advanced features with our premium subscription",
      features: ["Priority support", "Featured postings", "API access"],
    },
  ];

  return (
    <>
      <Navbar />
      <div className="min-h-screen bg-gray-50">
        {/* Header Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-16 px-4"
        >
          <div className="max-w-6xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Our Services</h1>
            <p className="text-xl text-blue-100">
              Comprehensive solutions for job seekers and employers
            </p>
          </div>
        </motion.div>

        {/* Top Ad Zone */}
        <div className="max-w-6xl mx-auto px-4 py-8">
          <AdZone zoneId="services-top" placement="inline" />
        </div>

        {/* Services Grid */}
        <div className="max-w-6xl mx-auto px-4 py-16">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => {
              const Icon = service.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-white rounded-lg shadow-lg p-8 hover:shadow-xl transition-shadow"
                >
                  <Icon className="w-12 h-12 text-blue-600 mb-4" />
                  <h3 className="text-xl font-bold text-gray-900 mb-2">
                    {service.title}
                  </h3>
                  <p className="text-gray-600 mb-4">{service.description}</p>
                  <ul className="space-y-2">
                    {service.features.map((feature, idx) => (
                      <li key={idx} className="text-sm text-gray-700">
                        ✓ {feature}
                      </li>
                    ))}
                  </ul>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Middle Ad Zone */}
        <div className="max-w-6xl mx-auto px-4 py-8">
          <AdZone zoneId="services-middle" placement="sticky" position="bottom" />
        </div>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          className="bg-gradient-to-r from-green-600 to-green-800 text-white py-16 px-4 my-16"
        >
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-4">Ready to get started?</h2>
            <p className="text-lg text-green-100 mb-8">
              Join thousands of professionals already using our platform
            </p>
            <button className="bg-white text-green-600 px-8 py-3 rounded-lg font-semibold hover:bg-green-50 transition-colors">
              Get Started Now
            </button>
          </div>
        </motion.div>

        {/* Bottom Ad Zone */}
        <div className="max-w-6xl mx-auto px-4 py-8">
          <AdZone zoneId="services-bottom" placement="floating" position="bottom" />
        </div>
      </div>
      <Footer />
    </>
  );
};

export default Services;
