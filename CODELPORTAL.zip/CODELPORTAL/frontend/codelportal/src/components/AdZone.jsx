import React, { useEffect, useState } from "react";
import axiosInstance from "../../utils/axiosInstance";
import { API_PATHS } from "../../utils/apiPaths";

const AdZone = ({ zoneId, placement = "inline", position = "bottom" }) => {
  const [adZone, setAdZone] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAdZone();
  }, [zoneId]);

  const fetchAdZone = async () => {
    try {
      // Get all zones and find the matching one
      const response = await axiosInstance.get(API_PATHS.ADS.GET_ALL_ZONES);
      const zone = response.data.find(z => z.zoneId === zoneId && z.isEnabled && z.isActive);
      
      if (zone) {
        setAdZone(zone);
        // Track impression
        await axiosInstance.post(`${API_PATHS.ADS.TRACK_IMPRESSION}/${zoneId}`);
      }
      setLoading(false);
    } catch (error) {
      console.error("Error fetching ad zone:", error);
      setLoading(false);
    }
  };

  if (loading || !adZone || !adZone.adsenseCode) {
    return null;
  }

  const handleAdClick = () => {
    axiosInstance.post(`${API_PATHS.ADS.TRACK_CLICK}/${zoneId}`);
  };

  // Determine styles based on placement
  const getStyles = () => {
    const baseStyles = {
      width: `${adZone.width}px`,
      height: `${adZone.height}px`,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      backgroundColor: "#f5f5f5",
      borderRadius: "8px",
      overflow: "hidden",
    };

    if (placement === "floating") {
      return {
        ...baseStyles,
        position: "fixed",
        zIndex: 999,
        [position === "bottom" ? "bottom" : "top"]: "20px",
        [position === "left" ? "left" : "right"]: "20px",
        boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
      };
    } else if (placement === "sticky") {
      return {
        ...baseStyles,
        position: "sticky",
        [position === "bottom" ? "bottom" : "top"]: "0",
        boxShadow: "0 -2px 8px rgba(0,0,0,0.1)",
      };
    }

    return {
      ...baseStyles,
      margin: "20px auto",
    };
  };

  return (
    <div 
      style={getStyles()} 
      onClick={handleAdClick}
      className="ad-zone"
      data-zone-id={zoneId}
    >
      {adZone.adsenseCode && (
        <div dangerouslySetInnerHTML={{ __html: adZone.adsenseCode }} />
      )}
    </div>
  );
};

export default AdZone;
