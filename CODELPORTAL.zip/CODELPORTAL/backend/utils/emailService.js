const nodemailer = require("nodemailer");
// NOTE: follower-related helpers removed to restore original state

// Configure email transporter (using Gmail with more secure options)
const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASSWORD,
    },
    tls: {
        rejectUnauthorized: false
    }
});

// Test connection
transporter.verify((error, success) => {
    if (error) {
        console.error("❌ Email configuration error:", error.message);
    } else {
        console.log("✅ Email service ready and authenticated");
    }
});

// Send welcome email to new user
const sendWelcomeEmail = async(email, name) => {
    try {
        console.log(`Attempting to send welcome email to ${email}`);
        const mailOptions = {
            from: process.env.EMAIL_USER,
            to: email,
            subject: "Bienvenue sur CODELPORTAL!",
            html: `
        <div style="font-family: Arial, sans-serif; color: #333;">
          <h2>Bienvenue sur CODELPORTAL, ${name}!</h2>
          <p>Votre compte a été créé avec succès.</p>
          <p>Vous pouvez maintenant:</p>
          <ul>
            <li>Parcourir les offres d'emploi</li>
            <li>Postuler aux offres</li>
            <li>Gérer votre profil</li>
          </ul>
          <p>Merci de nous avoir rejoints!</p>
          <p>Cordialement,<br/>L'équipe CODELPORTAL</p>
        </div>
      `,
        };

        const info = await transporter.sendMail(mailOptions);
        console.log(`✅ Welcome email sent to ${email}. Message ID: ${info.messageId}`);
        return { success: true, messageId: info.messageId };
    } catch (error) {
        console.error("❌ Error sending welcome email:", error.message);
        return { success: false, error: error.message };
    }
};

// Send application status update email to job seeker
const sendApplicationStatusEmail = async(email, name, jobTitle, status) => {
    try {
        console.log(`Attempting to send status email to ${email} for job ${jobTitle}`);
        const statusMessages = {
            "Applied": "Votre candidature a été reçue.",
            "In Review": "Votre candidature est en cours d'examen.",
            "Rejected": "Malheureusement, votre candidature a été rejetée.",
            "Accepted": "Félicitations! Votre candidature a été acceptée.",
        };

        const mailOptions = {
            from: process.env.EMAIL_USER,
            to: email,
            subject: `Mise à jour de votre candidature pour ${jobTitle}`,
            html: `
        <div style="font-family: Arial, sans-serif; color: #333;">
          <h2>Bonjour ${name},</h2>
          <p>Statut de candidature: <strong>${status}</strong></p>
          <p>${statusMessages[status] || "Votre candidature a été mise à jour."}</p>
          <p>Offre d'emploi: <strong>${jobTitle}</strong></p>
          <p>Merci d'avoir candidaté sur CODELPORTAL!</p>
          <p>Cordialement,<br/>L'équipe CODELPORTAL</p>
        </div>
      `,
        };

        const info = await transporter.sendMail(mailOptions);
        console.log(`✅ Status email sent to ${email}. Message ID: ${info.messageId}`);
        return { success: true, messageId: info.messageId };
    } catch (error) {
        console.error("❌ Error sending status email:", error.message);
        return { success: false, error: error.message };
    }
};

// Send OTP verification email
const sendOtpEmail = async(email, name, otp) => {
    try {
        console.log(`Attempting to send OTP email to ${email}`);
        const mailOptions = {
            from: process.env.EMAIL_USER,
            to: email,
            subject: "Votre code OTP - CODELPORTAL",
            html: `
        <div style="font-family: Arial, sans-serif; color: #333;">
          <h2>Vérification de votre email</h2>
          <p>Bonjour ${name},</p>
          <p>Voici votre code OTP pour vérifier votre email:</p>
          <div style="background-color: #f0f0f0; padding: 20px; border-radius: 5px; text-align: center;">
            <h1 style="color: #007bff; letter-spacing: 5px;">${otp}</h1>
          </div>
          <p>Ce code expire dans 10 minutes.</p>
          <p><strong>Ne partagez pas ce code avec d'autres personnes.</strong></p>
          <p>Si vous n'avez pas demandé ce code, ignorez cet email.</p>
          <p>Cordialement,<br/>L'équipe CODELPORTAL</p>
        </div>
      `,
        };

        const info = await transporter.sendMail(mailOptions);
        console.log(`✅ OTP email sent to ${email}. Message ID: ${info.messageId}`);
        return { success: true, messageId: info.messageId };
    } catch (error) {
        console.error("❌ Error sending OTP email:", error.message);
        return { success: false, error: error.message };
    }
};

// Send password reset email
const sendPasswordResetEmail = async(email, name, resetLink) => {
    try {
        console.log(`Attempting to send password reset email to ${email}`);
        const mailOptions = {
            from: process.env.EMAIL_USER,
            to: email,
            subject: "Réinitialiser votre mot de passe - CODELPORTAL",
            html: `
        <div style="font-family: Arial, sans-serif; color: #333;">
          <h2>Réinitialisation du mot de passe</h2>
          <p>Bonjour ${name},</p>
          <p>Vous avez demandé une réinitialisation de votre mot de passe. Cliquez sur le lien ci-dessous pour réinitialiser votre mot de passe:</p>
          <div style="margin: 30px 0;">
            <a href="${resetLink}" style="display: inline-block; background-color: #007bff; color: white; padding: 12px 30px; border-radius: 5px; text-decoration: none; font-weight: bold;">
              Réinitialiser le mot de passe
            </a>
          </div>
          <p>Ou copiez ce lien dans votre navigateur:</p>
          <p style="word-break: break-all; background-color: #f0f0f0; padding: 10px; border-radius: 5px;">${resetLink}</p>
          <p>Ce lien expire dans 1 heure.</p>
          <p><strong>Si vous n'avez pas demandé ceci, veuillez ignorer cet email.</strong></p>
          <p>Cordialement,<br/>L'équipe CODELPORTAL</p>
        </div>
      `,
        };

        const info = await transporter.sendMail(mailOptions);
        console.log(`✅ Password reset email sent to ${email}. Message ID: ${info.messageId}`);
        return { success: true, messageId: info.messageId };
    } catch (error) {
        console.error("❌ Error sending password reset email:", error.message);
        return { success: false, error: error.message };
    }
};

// (no follower notification helpers in original file)

module.exports = { sendWelcomeEmail, sendApplicationStatusEmail, sendOtpEmail, sendPasswordResetEmail };